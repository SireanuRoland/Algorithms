
class NodesList:

	__Nodes = dict();	

	@staticmethod
	def appendNode(arg_node):
		NodesList.__Nodes.update(arg_node);

#

	@staticmethod
	def showNodes():
		print(NodesList.__Nodes);


	@staticmethod
	def getValueOfKey(key):
		return NodesList.__Nodes.get(key);