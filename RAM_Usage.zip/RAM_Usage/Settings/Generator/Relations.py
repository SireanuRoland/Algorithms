

class Relations :

	relations = [["root"]];		# A list of lists

	@staticmethod
	def addToRelations(parent , child = None):

		parrentFound = False;
		

		#If child != None => Search for his parrent
		if (child != None):			
			for row in Relations.relations:
				if(row[0] == parent):
			#If parrent has been found append child to list
				#if (parent in row):
					print(parent+" is in ");
					print(row);
					#print(parent+" is in list ");
					row.append(child);
					parrentFound = True;
					break;

			# If parrent has not been found then append parrent and child 
			if (parrentFound == False):
				Relations.relations.append([parent , child]);

		#if child == None 
			#Search if parrent exist , otherwise add to list
		else :

			for row in Relations.relations:
				if(row[0] == parent):
				#if (parent in row):
					parrentFound = True;

			if(parrentFound == False):
				Relations.relations.append([parent]);
			
	def getNeighborsOfNode(node):
		for row in Relations.relations:
				if(row[0] == node):
					if(len(row)>1):
						return row[1:];
					else:
						return None;



#Relations.addToRelations("A","Z");