
# ---------------------------------------------------------------------------------------------
# RoSi - 03.03.2017	-
# Purpose : extract resource consumption from lst files and memory map of Sensor project
# ---------------------------------------------------------------------------------------------


import re
import os 
from Nodes import *
from Relations import *

PROJECT_LOC = "..//..//Debug//";

# ------------- Regular expressions ---------------- # 


stackUsage = re.compile(r"\s+(\d+\s*\d*)\s+(\w+)");
areaIdentifier = re.compile(r"\s+CSTACK\sFunction\s*");

class ParserState:
	FINDING_AREA_STATE = 0;
	FINDING_PARRENT = 1 ; 
	FINDING_CHILDREN = 2;


def getFileFromPath(arg_path):	
	location = arg_path.rfind("\\")	+ 1
	return arg_path[location:]
	

def findingParrent(arg_file):
	file = open(arg_file , "r");
	STATE = ParserState.FINDING_AREA_STATE;
	line = file.readline();

	while line:

		if(STATE == ParserState.FINDING_AREA_STATE):
			regexMatch = re.search(r"\s+CSTACK\sFunction\s*" , line);
			if (regexMatch):
				STATE = ParserState.FINDING_PARRENT;

		if(STATE == ParserState.FINDING_PARRENT):
			regexMatch = re.search(r"\s+(\d+\s*\d*)\s+(\w+)" , line);
			if (regexMatch):	
				#print(regexMatch.group(1)+ " AND "+regexMatch.group(2));
				NodesList.appendNode({str(regexMatch.group(2)):int(regexMatch.group(1))});
				Relations.addToRelations(str(regexMatch.group(2)));

		line = file.readline();

	file.close();
	


def findingChildren(arg_file):
	file = open(arg_file , "r");
	STATE = ParserState.FINDING_AREA_STATE;
	line = file.readline();
	Parent = "";

	while line:

		if(STATE == ParserState.FINDING_AREA_STATE):
			regexMatch = re.search(r"\s+CSTACK\sFunction\s*" , line);
			if (regexMatch):
				STATE = ParserState.FINDING_PARRENT;

		if(STATE == ParserState.FINDING_PARRENT):
			regexMatch = re.search(r"\s+(\d+\s*\d*)\s+(\w+)" , line);
			if (regexMatch):
				#print("PARENT : "+str(regexMatch.group(0)))
				STATE = ParserState.FINDING_CHILDREN;
				Parent = regexMatch.group(2);

		if(STATE == ParserState.FINDING_CHILDREN):			
			lastLine = file.tell();
			line = file.readline();			
			while line :
					regexMatch = re.search(r"\s+(\d+\s*\d*)\s+(\w+)" , line);
					if regexMatch :
						file.seek(lastLine);
						STATE = ParserState.FINDING_PARRENT;
						break;
					else:
						regexMatch = re.search(r"\s*(\d+\s*\d*)\s*->\s*(\w+)" , line);
						if regexMatch:
							#print("			CHILD : "+str(regexMatch.group(0)));
							print("AddToRelations("+Parent+" , "+str(regexMatch.group(2))+" )");
							Relations.addToRelations(Parent , str(regexMatch.group(2)));
							#Add it to Relations
					lastLine = file.tell();
					line = file.readline();


		line = file.readline();

	file.close();
	

def TRV(N , Sum , Stack = []):

	
	#print(N);		
	Stack.append(N);

	Sum += int(NodesList.getValueOfKey(N));	

	neighborsOfNode = Relations.getNeighborsOfNode(N);

	if (neighborsOfNode != None):
		for NeighOfNode in neighborsOfNode:			
			TRV(NeighOfNode,Sum);


	if (Sum > 32):
		for i in Stack:
			print(i+" , ");
		print(Sum);

	Stack.remove(N);

def run():
	for subdir, dirs, files in os.walk(PROJECT_LOC):
		for file in files:			
			filepath = subdir + os.sep + file

			if filepath.endswith(".lst"):
				#print(filepath);
				findingParrent(filepath);
				findingChildren(filepath);			
        
	print("\n\n");
	print(Relations.relations);  


	print("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
	#print(Relations.getNeighborsOfNode("Function4"));
	#if(Relations.getNeighborsOfNode("Function3") == None):
	#	print("Yes , indeed none");

	#print(NodesList.getValueOfKey("Function1"));
	
	TRV("Function1",0);

if __name__  == "__main__":
	run();
